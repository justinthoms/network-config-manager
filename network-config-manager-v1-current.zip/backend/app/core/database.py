from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from app.core.config import settings

connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    from app.models.user import User
    from app.models.device import Device
    from app.models.backup import Backup
    from app.models.schedule import BackupSchedule
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        from app.core.security import hash_password
        if not db.query(User).filter(User.username == settings.default_admin_username).first():
            db.add(User(
                username=settings.default_admin_username,
                password_hash=hash_password(settings.default_admin_password),
                role="admin",
                is_active=True,
            ))
            db.commit()
    finally:
        db.close()
